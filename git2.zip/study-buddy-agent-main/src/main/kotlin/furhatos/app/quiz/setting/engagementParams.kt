package furhatos.app.quiz.setting

import furhatos.flow.kotlin.voice.PollyVoice
import furhatos.util.Gender
import furhatos.util.Language

val maxNumberOfUsers = 1
val distanceToEngage = 1.5