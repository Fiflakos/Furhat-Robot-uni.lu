# ComplimentBot

This skill makes the robot wake up and give a compliment to each person that appears.

It will remember who it has given a compliment to and only gives a person one compliment.

It is an offshoot of the original fortune teller skill.