# Dog
Showcase of a dog character called Lucky. 

## Description
Who's a good boy? Engage with Lucky the dog and make it more excited, but eventually it will grow tired. A skill for non-verbal (not counting barks) communication! 

## Usage
Max number of users: 4
Requirements: Dog mask