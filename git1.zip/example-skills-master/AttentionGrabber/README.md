# ComplimentBot

This skill waits for a user to approach, greets them gives them compliment. When it does not get any attention it will get "bored" and eventually fall asleep.

The skill is using The Anime face and Microsoft Azure voice. 
