# Quiz
Compete with a friend in a quiz game

## Description
Partake in a quiz game with the robot where it will ask you and your friends multiple choice questions and receive a 
score for every correct answer. 

## Usage
Max number of users is set to: 2
No other specific requirements. 