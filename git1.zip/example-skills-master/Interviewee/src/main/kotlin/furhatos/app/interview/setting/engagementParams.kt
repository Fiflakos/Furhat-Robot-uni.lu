package furhatos.app.interview.setting

val maxNumberOfUsers = 1
val distanceToEngage = 1.5