# Interviewee
Wizard and interaction for Furhat to give an interview

## Description
This is a wizarded interaction for preparing the robot with answers to questions in a interview situation

## Usage
Max number of users is set to: 1
Requires a "wizard" to control the robot in real-time