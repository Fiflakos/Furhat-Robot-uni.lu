# OpenAIChat

## Description
Example skill to showcase the power of Language models like the GPT3 from OpneAI to generate natural language. 
Create a character and instruct the chatbot with a simple prompt. 

## Usage
Max number of users is set to: 2

### Requirements:
API key for OpenAI GPT3 language model. Request it from https://openai.com/api/
Some characters requires Acapela Voices 'WillFromAfar' that are only available on robots. 
