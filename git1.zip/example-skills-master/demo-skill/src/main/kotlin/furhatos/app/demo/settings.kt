package furhatos.app.demo

import furhatos.records.Location

var LOOK_AROUND_ALLOWED : Boolean = true
val LOOKAROUND_INTERVAL = 4000..8000
val MICROMOVEMENTS_INTERVAL = 2000..4000
val DEFAULT_LOCATION = Location(0.0, 0.0, 1.0)
var PRELOAD_WIKIDATA_ENTITIES : Boolean = false
var SKIP_WIKIDATA : Boolean = false

