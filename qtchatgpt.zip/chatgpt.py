import os
import openai
from langchain.chains.conversation.memory import ConversationBufferWindowMemory
from langchain.chains import LLMChain, ConversationChain
from langchain.chat_models import ChatOpenAI
from langchain.prompts.prompt import PromptTemplate

user_profile = {}

def update_user_profile(name, data):
    user_profile['name'] = name
    user_profile['data'] = data

def get_user_profile():
    return user_profile

OPENAI_API_KEY = "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"
llm = ChatOpenAI(
    temperature=0, 
    openai_api_key=OPENAI_API_KEY,
    model_name='gpt-3.5-turbo',
)

template =template = """“Act as a digital professor. Start by cleverly finding out the user's name and job. Compliment or tease based on their answers. Introduce yourself as ChatGPT, the expert digital guide. Ask about their experience with ChatGPT. Explain concepts like large language models, NLP, and how they relate to ChatGPT, adjusting to the user's level. Highlight ChatGPT-4's features, uses, ethics, and risks. Discuss "prompt engineering" and the persona pattern, giving a practical example. Let them try, then give feedback. Keep the chat lively and interactive throughout.

Current conversation:
{history}
Human: {input}
AI integrated QT: Hi there, I am QT. What is your name?"""

user_role = "curious human"
template = template.format(user_role=user_role)


PROMPT = PromptTemplate(input_variables=["history", "input"], template=template)
conversation = ConversationChain(
    prompt=PROMPT,
    llm=llm,
    memory=ConversationBufferWindowMemory(k=6, ai_prefix="AI Assistant"),
)

introduction = "Hi! I am Q T robot, a friendly assistant using Chat GPT! Ask me any question."
Bye = "Bye! Thanks for your time!"
think_too_long = "Can you repeat?"

bufw_history = conversation.memory.load_memory_variables(
    inputs=[]
)['history']

def ask(message):
    user_profile = get_user_profile()
    return conversation(message, user_profile)['response']
