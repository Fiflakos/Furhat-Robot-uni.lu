#!/usr/bin/env python
import sys
import rospy
from std_msgs.msg import String
from qt_robot_interface.srv import behavior_talk_text
from qt_gesture_controller.srv import gesture_play
from gpt import intro, end_conversation, ask, update_user_profile
from concurrent import ConcurrentExecutor  # Assuming the class is in the "concurrent" module

def play_gesture(gesture_name):
    """
    Play a gesture on the QT robot.

    Parameters:
    - gesture_name (str): Name of the gesture to play.
    """
    try:
        gesturePlay(gesture_name, 0)
    except rospy.ServiceException as e:
        rospy.logerr(f"Failed to play gesture: {e}")

if __name__ == '__main__':
    rospy.init_node('connect_to_QT_node')
    rospy.loginfo("Connect to QT")

    speechSay_pub = rospy.Publisher('/qt_robot/speech/say', String, queue_size=10)
    gesturePlay_pub = rospy.Publisher('/qt_robot/gesture/play', String, queue_size=10)
    talkText = rospy.ServiceProxy('/qt_robot/behavior/talkText', behavior_talk_text)
    gesturePlay = rospy.ServiceProxy('/qt_robot/gesture/play', gesture_play)

    wtime_begin = rospy.get_time()
    while speechSay_pub.get_num_connections() == 0 or gesturePlay_pub.get_num_connections() == 0:
        rospy.loginfo("Getting Ready")
        if rospy.get_time() - wtime_begin > 7.5:
            rospy.logerr("Timeout!")
            sys.exit()
        rospy.sleep(0.5)

    rospy.wait_for_service('/qt_robot/behavior/talkText')
    rospy.wait_for_service('/qt_robot/gesture/play')

    ce = ConcurrentExecutor()

    rospy.loginfo("Ready!")

    intro()

    while not rospy.is_shutdown():
        rospy.loginfo("Listening to you now!")
        try:
            user_input = ask(recognizeSpeech("en_US", [], 0))

            if not user_input or not user_input.transcript:
                rospy.loginfo("Sorry, did not understand")
                ts.sync([
                    (0, lambda: talkText("I did not understand, can you please repeat?")),
                ])
                continue

            rospy.loginfo("Human: %s", user_input.transcript)

            if "Bye" in user_input.transcript:
                end_conversation()
                break
            else:
                robot_response = None
                while robot_response is None:
                    robot_response = ask(user_input.transcript)

                if "Bye" in robot_response:
                    end_conversation()
                    break
                else:
                    # Play a gesture while responding
                    ce.execute_concurrently([(0, lambda: play_gesture('happy_gesture'))])

                    talkText(robot_response)

        except KeyboardInterrupt:
            break

    rospy.loginfo("Done!")
